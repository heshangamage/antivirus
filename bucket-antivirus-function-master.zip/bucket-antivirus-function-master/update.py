# -*- coding: utf-8 -*-
# Upside Travel, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os

import boto3

import clamav
from common import AV_DEFINITION_PATH
from common import AV_DEFINITION_S3_BUCKET
from common import AV_DEFINITION_S3_PREFIX
from common import CLAMAVLIB_PATH
from common import get_timestamp
import shutil


def lambda_handler(event, context):
    s3_client = boto3.client("s3")

    print("Script starting at %s\n" % (get_timestamp()))

    # Clear the existing definitions directory
    for root, dirs, files in os.walk(AV_DEFINITION_PATH):
        for f in files:
            os.unlink(os.path.join(root, f))
        for d in dirs:
            shutil.rmtree(os.path.join(root, d))

    # Download new definitions from S3
    clamav.update_defs_from_s3(s3_client, AV_DEFINITION_S3_BUCKET, AV_DEFINITION_S3_PREFIX)

    print("Skipping clamav definition download %s\n" % (get_timestamp()))

    # Log the environment variables
    print("Environment variables:", os.environ)

    # Log the LD_LIBRARY_PATH
    print("LD_LIBRARY_PATH:", os.getenv("LD_LIBRARY_PATH"))

    # Log the contents of CLAMAVLIB_PATH
    if os.path.exists(CLAMAVLIB_PATH):
        print("Contents of CLAMAVLIB_PATH:", os.listdir(CLAMAVLIB_PATH))
    else:
        print("CLAMAVLIB_PATH does not exist:", CLAMAVLIB_PATH)

    # Attempt to update definitions using freshclam
    try:
        return_code = clamav.update_defs_from_freshclam(AV_DEFINITION_PATH, CLAMAVLIB_PATH)
        if return_code != 0:
            raise Exception(f"freshclam exited with code {return_code}")
    except Exception as e:
        print("Error running freshclam:", str(e))
        raise

    # Check if main.cud exists and force freshclam to download compressed version if needed
    main_cud_path = os.path.join(AV_DEFINITION_PATH, "main.cud")
    if os.path.exists(main_cud_path):
        os.remove(main_cud_path)
        main_cvd_path = os.path.join(AV_DEFINITION_PATH, "main.cvd")
        if os.path.exists(main_cvd_path):
            os.remove(main_cvd_path)
        clamav.update_defs_from_freshclam(AV_DEFINITION_PATH, CLAMAVLIB_PATH)

    # Upload new definitions to S3
    clamav.upload_defs_to_s3(s3_client, AV_DEFINITION_S3_BUCKET, AV_DEFINITION_S3_PREFIX, AV_DEFINITION_PATH)
    print("Script finished at %s\n" % get_timestamp())